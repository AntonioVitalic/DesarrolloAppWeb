-- elimina la base de datos  "confessions_db"
DROP DATABASE IF EXISTS confessions_db;