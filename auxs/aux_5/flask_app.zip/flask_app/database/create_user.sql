-- Crear usuario
CREATE USER 'dbadmin'@'localhost' IDENTIFIED BY 'dbadmin';
